import os
os.system("bash run.sh")