bash alive.sh &
bash yt.sh